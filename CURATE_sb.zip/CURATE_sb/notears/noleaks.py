import numpy as np
from numpy.core.numeric import zeros_like
import scipy.linalg as slin
import scipy.optimize as sopt
from scipy.optimize import zeros
from notears.aGM import calibrateAnalyticGaussianMechanism

np.random.seed(0)


class PrivConfiguration:
    def __init__(self,  epsilon, delta):
        self.basic_epsilon = epsilon
        self.basic_delta = delta
        self.total_epsilon = .0
        self.total_delta = .0

        self.init_clipping_threshold = 1
        self.clipping_count = 0
        self.g_oracle_count = 0

        self.agm_sigma = {}
    
    def add_priv_budget(self, epsilon, delta):
        self.total_epsilon += epsilon
        self.total_delta += delta
    
    def add_basic_budget(self):
        self.add_priv_budget(self.basic_epsilon, self.basic_delta)
    
    def get_agm_sigma(self, sensitivity):
        if sensitivity not in self.agm_sigma:
            sigma = calibrateAnalyticGaussianMechanism(self.basic_epsilon, self.basic_delta, sensitivity)
            self.agm_sigma[sensitivity] = sigma
        return self.agm_sigma[sensitivity]
    
    def report_budget(self):
        print(F"epsilon: {self.total_epsilon}; delta: {self.total_delta}")
    
    def privacy_amplification(self, rate):
        print(F"amplified epsilon: {self.total_epsilon * rate}; amplified delta: {self.total_delta * rate}")
        return self.total_epsilon * rate


def noleaks(epsilon, delta, subsamplesize, X, pub_X=None, lambda1=0.1, max_iter=100, h_tol=1e-8, rho_max=1e+16, is_priv=True):
    """Solve min_W L(W; X) + lambda1 ‖W‖_1 s.t. h(W) = 0 using augmented Lagrangian.

    Args:
        X (np.ndarray): [n, d] sample matrix
        lambda1 (float): l1 penalty parameter
        loss_type (str): l2, logistic, poisson
        max_iter (int): max num of dual ascent steps
        h_tol (float): exit if |h(w_est)| <= htol
        rho_max (float): exit if rho >= rho_max
        w_threshold (float): drop edge if |weight| < threshold

    Returns:
        W_est (np.ndarray): [d, d] estimated DAG
    """

    def _loss(W):
        n, d = X.shape
        M = X @ W
        R = X - M
        loss = 0.5 / n * (R ** 2).sum()
        return loss
    
    def _dp_loss(W):
        n, d = pub_X.shape
        M = pub_X @ W
        R = pub_X - M
        loss = 0.5 / n * (R ** 2).sum()
        
        return loss

    def _G_loss(W):
        """Evaluate value and gradient of loss."""

        n, d = X.shape

        M = X @ W
        R = X - M
        
        G_loss = - 1.0 / n * X.T @ R

        return G_loss

    def _dp_G_loss(W):
        """Evaluate value and gradient of loss."""
        n, d = X.shape

        M = X @ W
        R = X - M
        
        G_loss = - 1.0 / n * X.T @ R

        clipping_threshold = 2
        l2_sensitivity = np.sqrt(d * (d - 1)) * clipping_threshold * 2 / n
        
        sigma = priv_config.get_agm_sigma(l2_sensitivity)

        G_loss_priv = np.clip(G_loss, -clipping_threshold, clipping_threshold) + np.random.normal(0, sigma, G_loss.shape)
        #print("*")
        # if np.abs(np.mean(G_loss_priv)) < sigma: return np.zeros_like(G_loss_priv)
        np.fill_diagonal(G_loss_priv, 0)

        priv_config.clipping_count += 1
        priv_config.add_basic_budget()

        return G_loss_priv

    def _h(W):
        """Evaluate value and gradient of acyclicity constraint."""
        E = slin.expm(W * W)  # (Zheng et al. 2018)
        h = np.trace(E) - d
        # A different formulation, slightly faster at the cost of numerical stability
        # M = np.eye(d) + W * W / d  # (Yu et al. 2019)
        # E = np.linalg.matrix_power(M, d - 1)
        # h = (E.T * M).sum() - d
        return h

    def _G_h(W):
        """Evaluate value and gradient of acyclicity constraint."""
        E = slin.expm(W * W)  # (Zheng et al. 2018)
        # A different formulation, slightly faster at the cost of numerical stability
        # M = np.eye(d) + W * W / d  # (Yu et al. 2019)
        # E = np.linalg.matrix_power(M, d - 1)
        G_h = E.T * W * 2
        return G_h

    def _adj(w):
        """Convert doubled variables ([2 d^2] array) back to original variables ([d, d] matrix)."""
        return (w[:d * d] - w[d * d:]).reshape([d, d])

    def _dp_G_obj_func(w):
        """Evaluate value and gradient of augmented Lagrangian for doubled variables ([2 d^2] array)."""
        W = _adj(w)
        G_loss = _dp_G_loss(W)
        h = _h(W)
        G_h = _G_h(W)
        G_smooth = G_loss + (rho * h + alpha) * G_h
        g_obj = np.concatenate((G_smooth + lambda1, - G_smooth + lambda1), axis=None)
        return g_obj
    
    def _G_obj_func(w):
        """Evaluate value and gradient of augmented Lagrangian for doubled variables ([2 d^2] array)."""
        W = _adj(w)
        G_loss = _G_loss(W)
        h = _h(W)
        G_h = _G_h(W)
        G_smooth = G_loss + (rho * h + alpha) * G_h
        g_obj = np.concatenate((G_smooth + lambda1, - G_smooth + lambda1), axis=None)
        return g_obj
    
    def _obj_func(w):
        W = _adj(w)
        loss = _loss(W)
        h = _h(W)
        obj = loss 
        obj += 0.5 * rho * h * h 
        obj += alpha * h 
        obj += lambda1 * w.sum()
        return obj
    
    def _dp_obj_func(w):
        #print("1")
        W = _adj(w)
        loss = _dp_loss(W)
        h = _h(W)
        obj = loss
        obj += 0.5 * rho * h * h 
        obj += alpha * h 
        obj += lambda1 * w.sum()
        return obj


    n, d = X.shape
    if not isinstance(pub_X, (np.ndarray, np.generic) ):
        subsample_size = subsamplesize
        pub_X = X[:subsample_size]
        epsilon = np.log((n+1)/(n+1-subsample_size))
        delta = subsample_size/n
        priv_config.add_priv_budget(epsilon, delta)
    
    w_est, rho, alpha, h = np.zeros(2 * d * d), 1.0, 0.0, np.inf  # double w_est into (w_pos, w_neg)

    bnds = [(0, 0) if i == j else (0, None) for _ in range(2) for i in range(d) for j in range(d)]
    # X = X - np.mean(X, axis=0, keepdims=True)
    # pub_X = pub_X  - np.mean(X, axis=0, keepdims=True)
    subsample_size = subsamplesize
    eps_cal = []
    leakage = []
    for iterations in range(max_iter):
        ##print(iterations)
        ##eps = epsilon +((iterations/max_iter)*epsilon)
        ##eps = epsilon**(1+(iterations/max_iter))
        eps = epsilon * (np.exp(iterations/max_iter))
        ##eps = epsilon * (np.exp(epsilon*(iterations/max_iter)))
        priv_config = PrivConfiguration(eps, delta)
        w_new, h_new = None, None
        while rho < rho_max:
            #print("*")
            if is_priv:
                sol = sopt.minimize(_dp_obj_func, w_est, method='L-BFGS-B', jac=_dp_G_obj_func, bounds=bnds)
            else:
                sol = sopt.minimize(_obj_func, w_est, method='L-BFGS-B', jac=_G_obj_func, bounds=bnds)
            w_new = sol.x
            h_new = _h(_adj(w_new))
            if h_new > 0.25 * h:
                rho *= 10
            else:
                break
        w_est, h = w_new, h_new
        alpha += rho * h
        if h <= h_tol or rho >= rho_max:
            print("early stop", h, rho)
            break
        eps_cal.append(priv_config.total_epsilon)
        print(eps_cal[iterations])
    W_est = _adj(w_est)
    #epsvalue = np.mean(eps_cal) 
    eps_value = np.sum(eps_cal)
    epsvalue = eps_value * (subsample_size/100000)
    #epsvalue = eps_value *(subsample_size/100000)
    #epsvalue = np.log(1+((subsample_size/100000)*(np.exp(eps_value)-1)))

    #epsvalue = priv_config.privacy_amplification(subsample_size/100000)
    #print("Amplified total leakage: ",epsvalue)
    #print("Total Leakage: ", priv_config.total_epsilon)
    return W_est, epsvalue
